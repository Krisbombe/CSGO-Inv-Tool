Java Fix Registry
- Entpacken sie die Java Fix.7z
- Führen sie die "java fix.reg" aus
- Klicken sie sich durch den Vorgang
- Sobald dieser Vorgang abgeschlossen ist
  sollte die "CSGOInvTool.jar" per Doppelklick
  geöffnet werden können.
- Falls nicht öffnen sie das Troubleshooting.